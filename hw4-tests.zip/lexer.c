/* $Id: lexer.c,v 1.6 2024/10/23 13:38:20 leavens Exp $ */

#include "lexer.h"

// All the functions declared in lexer.h are
// defined in the user code section of spl_lexer.l
